import cv2
img=cv2.imread("dog1.jpg")
print(img.shape)
cv2.imshow("title",img)
cv2.waitKey(0)
cv2.destroyAllWindows()
