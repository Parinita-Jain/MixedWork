import cv2
print("Hello India")