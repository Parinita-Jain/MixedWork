import streamlit as st
import pickle
import numpy as np

st.image("group_pic.jpg")
st.write('# Welcome To Insurance Company')
#write() inbuilt method of streamlit class , to show print the any message and value
#of variable on page
#user input :- numeric type value , use inbuilt method number_input() of streamlit class
#number_input() : accept int type value or float type value both
age=st.number_input('Enter Age',format="%d",value=0)
sex=st.radio('Enter gender 1-male , 0-female',[0,1])
bmi=st.number_input('Enter BMI')
#children=st.radio('Select Children',[0,1,2,3,4,5])
children=st.selectbox('Select Children',[0,1,2,3,4,5])
smoker=st.radio('Enter Smoker 0-No/1-Yes',[0,1])
region=st.selectbox('Select Region 0-East,1-North,2-South,3-West',[0,1,2,3])
charges=st.number_input('Enter Charges')
#st.write('age',age)
#st.write('Gender ',sex)
#to store all variables in list , take care of sequence as per given dataset
L=[age,sex,bmi,children,smoker,region,charges]
import numpy as np
features=np.array([L]) #convert list L into numpy array
#To read file
file1=open("scale.pkl","rb")

file2=open("model.pkl","rb")
#to load both file
scale=pickle.load(file1)
model=pickle.load(file2)
if st.button('Predict'):
    #Apply Scaling on features
    features=scale.transform(features)
    Y_pred=model.predict(features)[0]
    if(Y_pred==0):
        st.write("# Customer will not claim for insurance")
    else:
        st.write("# Customer will claim for insurance")
        
file1.close()
file2.close()
    
    
    
    
    
    
    
    
    



